﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LAB_06
{
    public partial class HeSoanThao : Form
    {
        int index = 0;
        int index1 = 0;
        int index2 = 0;
        public static Font Using = new Font("Time new roman", 13, FontStyle.Regular);
        public HeSoanThao()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void FontRichTextBox()
        {
            //MessageBox.Show(Using.Name);   
            if(index==1 && index1==0 && index2==0)
            {
                Using = new Font(Using.Name, Using.Size, FontStyle.Bold);
            }
            if (index == 0 && index1 == 1 && index2 == 0)
            {
                Using= new Font(Using.Name, Using.Size, FontStyle.Italic);
            }
            if (index == 0 && index1 == 0 && index2 == 1)
            {
                 Using= new Font(Using.Name, Using.Size, FontStyle.Underline);
            }
            if (index == 1 && index1 == 1 && index2 == 0)
            {
                Using= new Font(Using.Name, Using.Size, FontStyle.Italic|FontStyle.Bold);
            }
            if (index == 1 && index1 == 0 && index2 == 1)
            {
                Using= new Font(Using.Name, Using.Size, FontStyle.Bold|FontStyle.Underline);
            }
            if (index == 0 && index1 == 1 && index2 == 1)
            {
                 Using = new Font(Using.Name, Using.Size, FontStyle.Italic|FontStyle.Underline);
            }
            if (index == 1 && index1 == 1 && index2 == 1)
            {
                 Using = new Font(Using.Name, Using.Size, FontStyle.Italic|FontStyle.Bold|FontStyle.Underline);
            }
            if (index == 0 && index1 == 0 && index2 == 0)
            {
                 Using = new Font(Using.Name, Using.Size, FontStyle.Regular);
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if(index==0)
            {
                toolStripButton1.BackColor = Color.Gray;
                index = index + 1;
                FontRichTextBox();
                richTextBox1.SelectionFont = Using;
            }
            else
            {
                index = index - 1;
                FontRichTextBox();
                richTextBox1.SelectionFont = Using;
                toolStripButton1.BackColor = Color.White;
                
            }
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Copy();
        }

        private void pastToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Paste();
        }

        private void cut_Click(object sender, EventArgs e)
        {
            richTextBox1.Cut();
        }

        private void HeSoanThao_Load(object sender, EventArgs e)
        {
            FontFamily[] Font = FontFamily.Families;
            foreach(FontFamily item in Font)
            {
                mnuFont.Items.Add(item.Name);
            }
            for(int i=8;i<=72;i++)
            {
                mnuSize.Items.Add(i.ToString());
            }
            richTextBox1.SelectionFont = Using;
        }

        private void wordCountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(richTextBox1.SelectionLength.ToString());
        }

        private void mnuFind_Click(object sender, EventArgs e)
        {
            FindandReplace form = new FindandReplace();
            form.Owner = this;
            form.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if (index1 == 0)
            {
                    toolStripButton2.BackColor = Color.Gray;
                index1 = index1 + 1;
                FontRichTextBox();
                richTextBox1.SelectionFont = Using;
            }
            else
            {
                index1 = index1 - 1;
                FontRichTextBox();
                richTextBox1.SelectionFont = Using;
                toolStripButton2.BackColor = Color.White;

            }

        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.InitialDirectory = Application.StartupPath;
            openFileDialog1.Filter = "Rich Text Format(*.RTF)|*.RTF";
            openFileDialog1.FileName = "";
            openFileDialog1.ShowDialog();
            string path = openFileDialog1.FileName;
            richTextBox1.LoadFile(path);
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.InitialDirectory = Application.StartupPath;
            saveFileDialog1.Filter = "Rich Text Format(*.RTF)|*.RTF";
            saveFileDialog1.ShowDialog();
            string path = saveFileDialog1.FileName;
            richTextBox1.SaveFile(path);
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            richTextBox1.SelectionColor = colorDialog1.Color;
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
        }

        private void mnuFont_TextChanged(object sender, EventArgs e)
        {
            Using = new Font(mnuFont.Text, Using.Size, Using.Style);
            richTextBox1.SelectionFont = Using;
        }

        private void mnuSize_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Using = new Font(Using.Name, Convert.ToInt32(mnuSize.Text), Using.Style);
                richTextBox1.SelectionFont = Using;
            }catch(Exception ex)
            {
                return;
            }
            
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            if (index2 == 0)
            {
                toolStripButton4.BackColor = Color.Gray;
                index2 = index2 + 1;
                FontRichTextBox();
                richTextBox1.SelectionFont = Using;
            }
            else
            {
                index2 = index2 - 1;
                FontRichTextBox();
                richTextBox1.SelectionFont = Using;
                toolStripButton4.BackColor = Color.White;

            }
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (printDialog1.ShowDialog() == DialogResult.OK)
            {
                printDocument1.Print();
            }
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
        }

        private void printDocument1_BeginPrint(object sender, System.Drawing.Printing.PrintEventArgs e)
        {
            char[] param = { '\n' };

            if (printDialog1.PrinterSettings.PrintRange == System.Drawing.Printing.PrintRange.Selection)
            {
                lines = richTextBox1.SelectedText.Split(param);
            }
            else
            {
                lines = richTextBox1.Text.Split(param);
            }

            int i = 0;
            char[] trimParam = { '\r' };
            foreach (string s in lines)
            {
                lines[i++] = s.TrimEnd(trimParam);
            }
        }
        private int linesPrinted;
        private string[] lines;

        private void OnPrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            int x = e.MarginBounds.Left;
            int y = e.MarginBounds.Top;
            Brush brush = new SolidBrush(richTextBox1.ForeColor);

            while (linesPrinted < lines.Length)
            {
                e.Graphics.DrawString(lines[linesPrinted++],
                    richTextBox1.Font, brush, x, y);
                y += 15;
                if (y >= e.MarginBounds.Bottom)
                {
                    e.HasMorePages = true;
                    return;
                }
            }

            linesPrinted = 0;
            e.HasMorePages = false;
        }
    }
}
