﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace LAB_06
{
    public partial class SlideShow : Form
    {
        private string[] folderFile = null;
        private int selected = 0;
        private int begin = 0;
        private int end = 0;

        public SlideShow()
        {
            InitializeComponent();
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.RootFolder =
            Environment.SpecialFolder.Desktop;
            folderBrowserDialog1.SelectedPath = @"C:\Users\Public\Pictures\Sample Pictures";
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                string[] part1 = null, part2 = null, part3 = null;
                part1 = Directory.GetFiles(folderBrowserDialog1.SelectedPath, "*.jpg");
                part2 = Directory.GetFiles(folderBrowserDialog1.SelectedPath, "*.jpeg");
                part3 = Directory.GetFiles(folderBrowserDialog1.SelectedPath, "*.bmp");
                folderFile = new string[part1.Length + part2.Length + part3.Length];
                Array.Copy(part1, 0, folderFile, 0, part1.Length);
                Array.Copy(part2, 0, folderFile, part1.Length, part2.Length);
                Array.Copy(part3, 0, folderFile, part1.Length + part2.Length, part3.Length);
                selected = 0;

                showImage(folderFile[selected]);
                btnBack.Enabled = true;
                btnRight.Enabled = true;
                btnStart.Enabled = true;
            }
        }
        private void showImage(string path)
        {
            Image imgtemp = Image.FromFile(path);
            picShow.Image = imgtemp;
        }

        private void SlideShow_Load(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            if (selected == 0)
            {
                selected = folderFile.Length - 1;
                showImage(folderFile[selected]);
            }
            else
            {
                selected = selected - 1;
                showImage(folderFile[selected]);
            }
        }

        private void btnRight_Click(object sender, EventArgs e)
        {
            if (selected == folderFile.Length - 1)
            {
                selected = 0;
                showImage(folderFile[selected]);
            }
            else
            {
                selected = selected + 1;
                showImage(folderFile[selected]);
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            btnRight.PerformClick();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if (timer1.Enabled == true)
            {
                timer1.Enabled = false;
                btnStart.Text = "START Show";
            }
            else
            {
                timer1.Enabled = true;
                btnStart.Text = "STOP Show";
            }
        }
        private void btnFile_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Jpeg Files(*.JPG)|*.JPG|Icon Files (*.ico)|*.ico";
            openFileDialog1.ShowDialog();
            string path = openFileDialog1.FileName;
            Image imgtemp = Image.FromFile(path);
            picShow.Image = imgtemp;
        }
    }
}
