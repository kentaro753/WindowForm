﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace LAB_06
{
    public partial class DesignExploreProgram : Form
    {
        public DesignExploreProgram()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string path = @"D:\";
            TreeNode root = new TreeNode();
            root.Text = path;
            LoadTreeView(path,root);
            tvList.Nodes.Add(root);
        }

        private void tvList_AfterSelect(object sender, TreeViewEventArgs e)
        {
            listView1.Items.Clear();
            string path2 = e.Node.FullPath;
            LoadFilesInDirectory(path2);
        }
        public void LoadTreeView(string dirValue, TreeNode parentNode)
        {
            try
            {
                var folder = new DirectoryInfo(dirValue).GetDirectories();
                if(folder.Count()!=0)
                {
                    foreach(DirectoryInfo item in folder)
                    {

                    TreeNode node = new TreeNode(item.Name);
                    node.ImageIndex = 1;
                    parentNode.Nodes.Add(node);
                    LoadTreeView(item.FullName, node);
                     }
                 }
            }catch
            {
                return;
            }
            
        }
        public void LoadFilesInDirectory(string curDirectory)
        {
            try
            {
                DirectoryInfo[] node = new DirectoryInfo(curDirectory).GetDirectories();
                FileInfo[] file = new DirectoryInfo(curDirectory).GetFiles();
                foreach(DirectoryInfo item in node)
                {
                    ListViewItem folder = listView1.Items.Add(item.Name);
                    folder.SubItems.Add("");
                    folder.SubItems.Add("Folder");
                    folder.SubItems.Add(item.LastWriteTime.ToString());
                    folder.ImageIndex = 1;
            }
            foreach(FileInfo item in file)
            {
                ListViewItem File = listView1.Items.Add(item.Name);
                File.SubItems.Add(item.Length.ToString());
                File.SubItems.Add("File");
                File.SubItems.Add(item.LastWriteTime.ToString());
                File.ImageIndex = 3;
            }
            }catch
            {
                return;
            }
            
        }

        private void listToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listView1.View = View.List;
        }

        private void detailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listView1.View = View.Details;
        }
    }
}
