﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LAB_06
{
    public partial class FindandReplace : Form
    {
        public FindandReplace()
        {
            InitializeComponent();
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            HeSoanThao form = (HeSoanThao)this.Owner;
            int index = 0;
            var temp = form.richTextBox1.Text;
            form.richTextBox1.Text = "";
            form.richTextBox1.Text = temp;

            while (index <= form.richTextBox1.Text.LastIndexOf(txtFind.Text))
            {
                form.richTextBox1.Find(txtFind.Text, index, form.richTextBox1.TextLength, RichTextBoxFinds.None);
                form.richTextBox1.SelectionBackColor = Color.Yellow;
                
                index = form.richTextBox1.Text.IndexOf(txtFind.Text, index) + 1;
            }
        }
        public static void QuickReplace(RichTextBox rtb, String word, String word2)
        {
            rtb.Text = rtb.Text.Replace(word, word2);
        }
        private void btnReplace_Click(object sender, EventArgs e)
        {
            HeSoanThao form = (HeSoanThao)this.Owner;
            QuickReplace(form.richTextBox1, txtFind.Text, txtReplace.Text);
        }

        private void FindandReplace_FormClosed(object sender, FormClosedEventArgs e)
        {
            HeSoanThao form = (HeSoanThao)this.Owner;
            int index = 0;
            var temp = form.richTextBox1.Text;
            form.richTextBox1.Text = "";
            form.richTextBox1.Text = temp;

            while (index <= form.richTextBox1.Text.LastIndexOf(txtFind.Text))
            {
                form.richTextBox1.Find(txtFind.Text, index, form.richTextBox1.TextLength, RichTextBoxFinds.None);
                form.richTextBox1.SelectionBackColor = Color.White;

                index = form.richTextBox1.Text.IndexOf(txtFind.Text, index) + 1;
            }
        }
    }
}
