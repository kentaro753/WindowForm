﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO_QuanLyBanHang
{
    public class DTO_SanPham
    {
        string MaLoaiSP;
        string TenLoaiSP;

        public DTO_SanPham(string maLoaiSP, string tenLoaiSP)
        {
            MaLoaiSP = maLoaiSP;
            TenLoaiSP = tenLoaiSP;
        }

        public string MaLoaiSP1
        {
            get
            {
                return MaLoaiSP;
            }

            set
            {
                MaLoaiSP = value;
            }
        }

        public string TenLoaiSP1
        {
            get
            {
                return TenLoaiSP;
            }

            set
            {
                TenLoaiSP = value;
            }
        }
    }
}
