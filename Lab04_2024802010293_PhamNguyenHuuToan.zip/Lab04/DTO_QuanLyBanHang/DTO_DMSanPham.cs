﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO_QuanLyBanHang
{
    public class DTO_DMSanPham
    {
        string MaSP;
        string TenSP;
        int DG;
        string MaLoai;
        string HinhSanPham;
        string DVT;

        public string MaSP1
        {
            get
            {
                return MaSP;
            }

            set
            {
                MaSP = value;
            }
        }

        public string TenSP1
        {
            get
            {
                return TenSP;
            }

            set
            {
                TenSP = value;
            }
        }

        public int DG1
        {
            get
            {
                return DG;
            }

            set
            {
                DG = value;
            }
        }

        public string MaLoai1
        {
            get
            {
                return MaLoai;
            }

            set
            {
                MaLoai = value;
            }
        }

        public string HinhSanPham1
        {
            get
            {
                return HinhSanPham;
            }

            set
            {
                HinhSanPham = value;
            }
        }

        public string DVT1
        {
            get
            {
                return DVT;
            }

            set
            {
                DVT = value;
            }
        }

        public DTO_DMSanPham(string maSP, string tenSP, int dG, string maLoai, string hinhSanPham, string dVT)
        {
            MaSP1 = maSP;
            TenSP1 = tenSP;
            DG1 = dG;
            MaLoai1 = maLoai;
            HinhSanPham1 = hinhSanPham;
            DVT1 = dVT;
        }
    }
}
