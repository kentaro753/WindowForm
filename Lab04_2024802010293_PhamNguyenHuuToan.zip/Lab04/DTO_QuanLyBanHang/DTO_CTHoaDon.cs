﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO_QuanLyBanHang
{
    public class DTO_CTHoaDon
    {
        string MaHD;
        string MaSP;
        int SL;
        public DTO_CTHoaDon() { }
        public DTO_CTHoaDon(string maHD, string maSP, int sL)
        {
            MaHD = maHD;
            MaSP = maSP;
            SL = sL;
        }

        public string MaHD1
        {
            get
            {
                return MaHD;
            }

            set
            {
                MaHD = value;
            }
        }

        public string MaSP1
        {
            get
            {
                return MaSP;
            }

            set
            {
                MaSP = value;
            }
        }

        public int SL1
        {
            get
            {
                return SL;
            }

            set
            {
                SL = value;
            }
        }
    }
}
