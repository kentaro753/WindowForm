﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO_QuanLyBanHang
{
    public class DTO_NhanVien
    {
        string MaNV;
        string TenNV;
        string Add;
        string Phone;

        public string MaNV1
        {
            get
            {
                return MaNV;
            }

            set
            {
                MaNV = value;
            }
        }

        public string TenNV1
        {
            get
            {
                return TenNV;
            }

            set
            {
                TenNV = value;
            }
        }

        public string Add1
        {
            get
            {
                return Add;
            }

            set
            {
                Add = value;
            }
        }

        public string Phone1
        {
            get
            {
                return Phone;
            }

            set
            {
                Phone = value;
            }
        }

        public DTO_NhanVien(string maNV, string tenNV, string add, string phone)
        {
            MaNV1 = maNV;
            TenNV1 = tenNV;
            Add1 = add;
            Phone1 = phone;
        }
    }
}
