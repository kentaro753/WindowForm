﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO_QuanLyBanHang
{
    public class DTO_KhachHang
    {
        string MaKH;
        string TenKH;
        string Add;
        string Phone;
        string email;

        public DTO_KhachHang(string maKH, string tenKH, string add, string phone, string email)
        {
            MaKH = maKH;
            TenKH = tenKH;
            Add = add;
            Phone = phone;
            this.email = email;
        }

        public string MaKH1
        {
            get
            {
                return MaKH;
            }

            set
            {
                MaKH = value;
            }
        }

        public string TenKH1
        {
            get
            {
                return TenKH;
            }

            set
            {
                TenKH = value;
            }
        }

        public string Add1
        {
            get
            {
                return Add;
            }

            set
            {
                Add = value;
            }
        }

        public string Phone1
        {
            get
            {
                return Phone;
            }

            set
            {
                Phone = value;
            }
        }

        public string Email
        {
            get
            {
                return email;
            }

            set
            {
                email = value;
            }
        }
    }
}
