﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO_QuanLyBanHang
{
    public class DTO_HoaDon
    {
        string MaHD;
        string MaKH;
        string MaNV;
        DateTime NgayBan;

        public DTO_HoaDon(string maHD, string maKH, string maNV, DateTime ngayBan)
        {
            MaHD = maHD;
            MaKH = maKH;
            MaNV = maNV;
            NgayBan = ngayBan;
        }

        public string MaHD1
        {
            get
            {
                return MaHD;
            }

            set
            {
                MaHD = value;
            }
        }

        public string MaKH1
        {
            get
            {
                return MaKH;
            }

            set
            {
                MaKH = value;
            }
        }

        public string MaNV1
        {
            get
            {
                return MaNV;
            }

            set
            {
                MaNV = value;
            }
        }

        public DateTime NgayBan1
        {
            get
            {
                return NgayBan;
            }

            set
            {
                NgayBan = value;
            }
        }
    }
}
