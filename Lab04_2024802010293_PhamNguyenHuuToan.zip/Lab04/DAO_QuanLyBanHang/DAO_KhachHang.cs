﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DTO_QuanLyBanHang;
using System.Data.SqlClient;

namespace DAO_QuanLyBanHang
{
    public class DAO_KhachHang:DBConnect
    {

        public DataTable getKhachHang()
        {
            Connect();
            SqlDataAdapter ad = new SqlDataAdapter("select * from KhachHang", conn);
            DataTable table = new DataTable();
            ad.Fill(table);
            return table;
        }
        public bool themKhachHang(DTO_KhachHang tv)
        {
            
            try
            {
                Connect();
                string SQL = "INSERT INTO KhachHang VALUES (N'" + tv.MaKH1.Trim() +
                "',N'" + tv.TenKH1.Trim() + "',N'" + tv.Add1.Trim() + "','" + tv.Phone1.Trim() + "','" + tv.Email.Trim() + "')";
                SqlCommand cmd = new SqlCommand(SQL, conn);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                // Dong ket noi
                Disconnect();
            }

            return false;
        }
        public bool suaKhachHang(DTO_KhachHang tv)
        {
            
            try
            {
                Connect();
                string SQL = "Update KhachHang set TenKH=N'" + tv.TenKH1.Trim() + "',[Add]=N'" +
                tv.Add1.Trim() + "',[Phone] ='" + tv.Phone1.Trim() + "',[Email]='" + tv.Email.Trim() +
                "' WHERE MaKH=N'" + tv.MaKH1.Trim() + "'";
                SqlCommand cmd = new SqlCommand(SQL, conn);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                // Dong ket noi
                Disconnect();
            }

            return false;
        }
        public bool xoaKhachHang(string tv)
        {
            
            try
            {
                Connect();
                string SQL = "DELETE KhachHang WHERE MaKH=N'" + tv + "'";
                SqlCommand cmd = new SqlCommand(SQL, conn);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                // Dong ket noi
                Disconnect();
            }

            return false;
        }
        public DataTable KiemTraTonTai(string MaKH)
        {
            Connect();
            SqlDataAdapter ad = new SqlDataAdapter("select * from KhachHang WHERE MaKH=N'" + MaKH + "'", conn);
            DataTable table = new DataTable();
            ad.Fill(table);
            return table;
        }
    }
}
