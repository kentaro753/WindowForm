﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DTO_QuanLyBanHang;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DAO_QuanLyBanHang
{
    public class DAO_DMSanPham:DBConnect
    {
            public DataTable getDMSanPham()
            {
                Connect();
                SqlDataAdapter ad = new SqlDataAdapter("select * from DMSanPham", conn);
                DataTable table = new DataTable();
                ad.Fill(table);
                return table;
            }
            public bool themDMSanPham(DTO_DMSanPham tv)
            {

                try
                {
                    Connect();
                    string SQL = "INSERT INTO DMSanPham VALUES (N'" + tv.MaSP1.Trim() +
                    "',N'" + tv.TenSP1.Trim() + "'," + tv.DG1 + ",'" + tv.MaLoai1.Trim() + "','" + tv.HinhSanPham1.Trim() + "','" + tv.DVT1.Trim() + "')";
                    SqlCommand cmd = new SqlCommand(SQL, conn);
                    if (cmd.ExecuteNonQuery() > 0)
                        return true;
                }
                catch (Exception e)
                {

                }
                finally
                {
                    // Dong ket noi
                    Disconnect();
                }

                return false;
            }
            public bool suaDMSanPham(DTO_DMSanPham tv)
            {

                try
                {
                    Connect();
                    string SQL = "Update [dbo].[DMSanPham]  set [TenSP]=N'" + tv.TenSP1.Trim() + "',[DG]=" +
                    tv.DG1.ToString() + ",[MaLoai] =N'" + tv.MaLoai1.Trim() +"',[HinhSanPham] ='" + tv.HinhSanPham1.Trim() + "',[DVT] ='" + tv.DVT1.Trim() +
                    "' WHERE [MaSP]=N'" + tv.MaSP1.Trim() + "'";
                    SqlCommand cmd = new SqlCommand(SQL, conn);
                    if (cmd.ExecuteNonQuery() > 0)
                        return true;
                }
                catch (Exception e)
                {

                }
                finally
                {
                    // Dong ket noi
                    Disconnect();
                }

                return false;
            }
            public bool xoaDMSanPham(string tv)
            {

                try
                {
                    Connect();
                    string SQL = "DELETE DMSanPham WHERE MaSP=N'" + tv + "'";
                    SqlCommand cmd = new SqlCommand(SQL, conn);
                    if (cmd.ExecuteNonQuery() > 0)
                        return true;
                }
                catch (Exception e)
                {

                }
                finally
                {
                    // Dong ket noi
                    Disconnect();
                }

                return false;
            }
            public DataTable KiemTraTonTai(string MaNV)
            {
                Connect();
                SqlDataAdapter ad = new SqlDataAdapter("select * from DMSanPham WHERE MaSP=N'" + MaNV + "'", conn);
                DataTable table = new DataTable();
                ad.Fill(table);
                return table;
            }
        }
}
