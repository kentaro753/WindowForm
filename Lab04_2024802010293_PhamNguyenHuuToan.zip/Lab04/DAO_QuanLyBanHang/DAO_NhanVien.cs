﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DTO_QuanLyBanHang;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DAO_QuanLyBanHang
{
    public class DAO_NhanVien:DBConnect
    {
        public DataTable getNhanVien()
        {
            Connect();
            SqlDataAdapter ad = new SqlDataAdapter("select * from NhanVien", conn);
            DataTable table = new DataTable();
            ad.Fill(table);
            return table;
        }
        public bool themNhanVien(DTO_NhanVien tv)
        {

            try
            {
                Connect();
                string SQL = "INSERT INTO NhanVien VALUES (N'" + tv.MaNV1.Trim() +
                "',N'" + tv.TenNV1.Trim() + "',N'" + tv.Add1.Trim() + "','" + tv.Phone1.Trim() + "')";
                SqlCommand cmd = new SqlCommand(SQL, conn);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                // Dong ket noi
                Disconnect();
            }

            return false;
        }
        public bool suaNhanVien(DTO_NhanVien tv)
        {

            try
            {
                Connect();
                string SQL = "Update [dbo].[NhanVien]  set [TenNV]=N'" + tv.TenNV1.Trim() + "',[Add]=N'" +
                tv.Add1.Trim() + "',[Phone] ='" + tv.Phone1.Trim() +
                "' WHERE [MaNV]=N'" + tv.MaNV1.Trim() + "'";
                SqlCommand cmd = new SqlCommand(SQL, conn);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                // Dong ket noi
                Disconnect();
            }

            return false;
        }
        public bool xoaNhanVien(string tv)
        {

            try
            {
                Connect();
                string SQL = "DELETE NhanVien WHERE MaNV=N'" + tv + "'";
                SqlCommand cmd = new SqlCommand(SQL, conn);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                // Dong ket noi
                Disconnect();
            }

            return false;
        }
        public DataTable KiemTraTonTai(string MaNV)
        {
            Connect();
            SqlDataAdapter ad = new SqlDataAdapter("select * from NhanVien WHERE MaNV=N'" + MaNV + "'", conn);
            DataTable table = new DataTable();
            ad.Fill(table);
            return table;
        }
    }
}
