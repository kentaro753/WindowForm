﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace DAO_QuanLyBanHang
{
    public class DBConnect
    {
        public static SqlConnection conn;
        public static void Connect()
        {
            conn = new SqlConnection(); 
            //conn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=" + Application.StartupPath + @"\Quanlybanhang.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
            conn.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\thuchanhwindows\QuanLyBanHang\QuanLyBanHang\QuangLyBanHang.mdf;Integrated Security=True;Connect Timeout=30";
            conn.Open();
            if (conn.State == ConnectionState.Open) ;
            //MessageBox.Show("Kết nối thành công");
            else MessageBox.Show("Không thể kết nối với dữ liệu");

        }
        public static void Disconnect()
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();   	
                conn.Dispose(); 	
                conn = null;
            }
        }
    }
}
