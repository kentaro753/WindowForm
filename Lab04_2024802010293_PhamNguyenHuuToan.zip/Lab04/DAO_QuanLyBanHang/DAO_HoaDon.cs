﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DTO_QuanLyBanHang;
using System.Data.SqlClient;
using System.Windows.Forms;
namespace DAO_QuanLyBanHang
{
    public class DAO_HoaDon:DBConnect
    {
        public DataTable getHoaDon(string MaHang)
        {
            Connect();
            SqlDataAdapter ad = new SqlDataAdapter("SELECT a.MaHang, b.TenHang, a.SoLuong, b.DonGiaBan, a.GiamGia,a.ThanhTien FROM tblChiTietHDBan AS a, tblHang AS b WHERE a.MaHDBan = N'" + MaHang + "' AND a.MaHang=b.MaHang", conn);
            DataTable table = new DataTable();
            ad.Fill(table);
            return table;
        }
        public bool themHoaDon(DTO_HoaDon tv)
        {

            try
            {
                Connect();
                string SQL = "INSERT INTO HoaDon VALUES (N'" + tv.MaHD1.Trim() +
                "',N'" + tv.MaKH1.Trim() + "'," + tv.MaNV1 + ",'" + tv.NgayBan1.Date.ToString()+ "')";
                SqlCommand cmd = new SqlCommand(SQL, conn);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                // Dong ket noi
                Disconnect();
            }

            return false;
        }
        public bool xoaHoaDon(string tv)
        {

            try
            {
                Connect();
                string SQL = "DELETE HoaDon WHERE MaHD=N'" + tv + "'";
                SqlCommand cmd = new SqlCommand(SQL, conn);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                // Dong ket noi
                Disconnect();
            }

            return false;
        }
        public DataTable KiemTraTonTai(string MaNV)
        {
            Connect();
            SqlDataAdapter ad = new SqlDataAdapter("select * from HoaDon WHERE MaHD=N'" + MaNV + "'", conn);
            DataTable table = new DataTable();
            ad.Fill(table);
            return table;
        }
    }
}
