﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DTO_QuanLyBanHang;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DAO_QuanLyBanHang
{
    public class DAO_SanPham:DBConnect
    {
        public DataTable getSanPham()
        {
            Connect();
            SqlDataAdapter ad = new SqlDataAdapter("select * from SanPham", conn);
            DataTable table = new DataTable();
            ad.Fill(table);
            return table;
        }
        public bool themSanPham(DTO_SanPham tv)
        {

            try
            {
                Connect();
                string SQL = "INSERT INTO SanPham VALUES (N'" + tv.MaLoaiSP1.Trim() +
                "',N'" + tv.TenLoaiSP1.Trim() + "')";
                SqlCommand cmd = new SqlCommand(SQL, conn);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                // Dong ket noi
                Disconnect();
            }

            return false;
        }
        public bool suaSanPham(DTO_SanPham tv)
        {

            try
            {
                Connect();
                string SQL = "Update [dbo].[SanPham]  set [TenLoaiSP]=N'" + tv.TenLoaiSP1.Trim() +
                "' WHERE [MaLoaiSP]=N'" + tv.MaLoaiSP1.Trim() + "'";
                SqlCommand cmd = new SqlCommand(SQL, conn);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                // Dong ket noi
                Disconnect();
            }

            return false;
        }
        public bool xoaSanPham(string tv)
        {

            try
            {
                Connect();
                string SQL = "DELETE SanPham WHERE MaLoaiSP=N'" + tv + "'";
                SqlCommand cmd = new SqlCommand(SQL, conn);
                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            catch (Exception e)
            {

            }
            finally
            {
                // Dong ket noi
                Disconnect();
            }

            return false;
        }
        public DataTable KiemTraTonTai(string MaLoaiSp)
        {
            Connect();
            SqlDataAdapter ad = new SqlDataAdapter("select * from SanPham WHERE MaLoaiSP=N'" + MaLoaiSp + "'", conn);
            DataTable table = new DataTable();
            ad.Fill(table);
            return table;
        }
    }
}
