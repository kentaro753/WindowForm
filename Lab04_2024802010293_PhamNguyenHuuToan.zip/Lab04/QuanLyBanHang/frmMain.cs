﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyBanHang
{
    public partial class frmMain : Form
    {
        Form activeForm = null;
        public frmMain()
        {
            InitializeComponent();
        }

        private void mnuHoaDon_Click(object sender, EventArgs e)
        {
            frmHoaDon f = new frmHoaDon();
            if (activeForm != null)
                activeForm.Close();

            f.MdiParent = this;
            activeForm = f;
            f.TopLevel = false;
            f.FormBorderStyle = FormBorderStyle.None;
            f.Dock = DockStyle.Fill;
            f.WindowState = FormWindowState.Maximized;

            f.Show();
        }

        private void mnuKhachHang_Click(object sender, EventArgs e)
        {
            frmKhachHang f = new frmKhachHang();
            if (activeForm!= null)
                activeForm.Close();
           activeForm =f;
            f.MdiParent = this;
           
            f.TopLevel = false;
            f.FormBorderStyle = FormBorderStyle.None;
            f.Dock = DockStyle.Fill;
           f.WindowState = FormWindowState.Maximized;

            f.Show();
        }

        private void mnuNhanVien_Click(object sender, EventArgs e)
        {
            frmNhanVien f = new frmNhanVien();
            if (activeForm != null)
                activeForm.Close();

            f.MdiParent = this;
            activeForm = f;
            f.TopLevel = false;
            f.FormBorderStyle = FormBorderStyle.None;
            f.Dock = DockStyle.Fill;
            f.WindowState = FormWindowState.Maximized;

            f.Show();
        }

        private void mnuSanPham_Click(object sender, EventArgs e)
        {
            frmDanhMucSanPham f = new frmDanhMucSanPham();
            if (activeForm != null)
                activeForm.Close();

            f.MdiParent = this;
            activeForm = f;
            f.TopLevel = false;
            f.FormBorderStyle = FormBorderStyle.None;
            f.Dock = DockStyle.Fill;
            f.WindowState = FormWindowState.Maximized;

            f.Show();
        }

        private void mnuLoaiSanPham_Click(object sender, EventArgs e)
        {
            frmSanPham f = new frmSanPham();
            if (activeForm != null)
                activeForm.Close();

            f.MdiParent = this;
            activeForm = f;
            f.TopLevel = false;
            f.FormBorderStyle = FormBorderStyle.None;
            f.Dock = DockStyle.Fill;
            f.WindowState = FormWindowState.Maximized;

            f.Show();
        }
    }
}
