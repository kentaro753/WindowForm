﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DTO_QuanLyBanHang;
using BUS_QuanLyBanHang;


namespace QuanLyBanHang
{
    public partial class frmHoaDon : Form
    {
        BUS_NhanVien NhanVien = new BUS_NhanVien();
        BUS_KhachHang KhachHang = new BUS_KhachHang();
        BUS_HoaDon HoaDon = new BUS_HoaDon();
        BUS_DMSanPham SanPham = new BUS_DMSanPham();
        public frmHoaDon()
        {
            InitializeComponent();
        }
        private void LoadDataGridView()
        {
            dgvHDBanHang.DataSource = HoaDon.getHoaDon();
            dgvHDBanHang.Columns[0].HeaderText = "Mã hàng";
            dgvHDBanHang.Columns[1].HeaderText = "Tên hàng";
            dgvHDBanHang.Columns[2].HeaderText = "Số lượng";
            dgvHDBanHang.Columns[3].HeaderText = "Đơn giá";
            dgvHDBanHang.Columns[4].HeaderText = "Giảm giá %";
            dgvHDBanHang.Columns[5].HeaderText = "Thành tiền";
            dgvHDBanHang.Columns[0].Width = 80;
            dgvHDBanHang.Columns[1].Width = 130;
            dgvHDBanHang.Columns[2].Width = 80;
            dgvHDBanHang.Columns[3].Width = 90;
            dgvHDBanHang.Columns[4].Width = 90;
            dgvHDBanHang.Columns[5].Width = 90;
            dgvHDBanHang.AllowUserToAddRows = false;
            dgvHDBanHang.EditMode = DataGridViewEditMode.EditProgrammatically;
        }
        private void frmHoaDon_Load(object sender, EventArgs e)
        {
            btnThem.Enabled = true;
            btnLuu.Enabled = false;
            btnXoa.Enabled = false;
            txtMaHDBan.ReadOnly = true;
            txtTenNhanVien.ReadOnly = true;
            txtTenKhach.ReadOnly = true;
            txtDiaChi.ReadOnly = true;
            txtTenNhanVien.ReadOnly = true;
            txtTenHang.ReadOnly = true;
            txtDonGiaBan.ReadOnly = true;
            txtThanhTien.ReadOnly = true;
            txtTongTien.ReadOnly = true;
            txtGiamGia.Text = "0";
            txtTongTien.Text = "0";
            cboMaKhach.DataSource = KhachHang.getKhachHang();
            cboMaKhach.DisplayMember = KhachHang.getKhachHang().Columns[0].ToString();
            cboMaKhach.ValueMember = KhachHang.getKhachHang().Columns[0].ToString();
            cboMaKhach.SelectedIndex = -1;
            cboMaNhanVien.DataSource = NhanVien.getNhanVien();
            cboMaKhach.DisplayMember = NhanVien.getNhanVien().Columns[0].ToString();
            cboMaKhach.ValueMember = NhanVien.getNhanVien().Columns[0].ToString();
            cboMaNhanVien.SelectedIndex = -1;
            cboMaHang.DataSource = SanPham.getDMSanPham();
            cboMaHang.DisplayMember = SanPham.getDMSanPham().Columns[0].ToString();
            cboMaHang.ValueMember = SanPham.getDMSanPham().Columns[0].ToString();
            cboMaHang.SelectedIndex = -1;
            //Hiển thị thông tin của một hóa đơn được gọi từ form tìm kiếm
            if (txtMaHDBan.Text != "")
            {
                btnXoa.Enabled = true;
            }
            LoadDataGridView();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            btnXoa.Enabled = false;
            btnLuu.Enabled = true;
            btnThem.Enabled = false;
            ResetValues();
            txtMaHDBan.Text = Functions.CreateKey("HDB");
            LoadDataGridView();
        }
        private void ResetValues()
        {
            txtMaHDBan.Text = "";
            txtNgayBan.Text = DateTime.Now.ToShortDateString();
            cboMaNhanVien.Text = "";
            cboMaKhach.Text = "";
            txtTongTien.Text = "0";
            cboMaHang.Text = "";
            txtSoLuong.Text = "";
            txtGiamGia.Text = "0";
            txtThanhTien.Text = "0";
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
        }

    }
}

