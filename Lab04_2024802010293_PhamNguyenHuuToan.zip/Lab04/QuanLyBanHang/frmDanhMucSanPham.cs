﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BUS_QuanLyBanHang;
using DTO_QuanLyBanHang;

namespace QuanLyBanHang
{
    public partial class frmDanhMucSanPham : Form
    {
        BUS_DMSanPham DMSanPham = new BUS_DMSanPham();
        BUS_SanPham SanPham = new BUS_SanPham();
        public frmDanhMucSanPham()
        {
            InitializeComponent();
        }
        private void ResetValues()
        {
            txtMaSP.Text = "";
            txtTenSP.Text = "";
            cboMaLoai.Text = "";
            txtDonGia.Text = "0";
            txtDonGia.Enabled = false;
            txtAnh.Text = "";
            txtDonViTinh.Text = "";
            picAnh.Image = null;
        }
        private void LoadDataGridView()
        {
            
            dgvHang.DataSource = DMSanPham.getDMSanPham();
            dgvHang.Columns[0].HeaderText = "Mã hàng";
            dgvHang.Columns[1].HeaderText = "Tên hàng";
            dgvHang.Columns[3].HeaderText = "Loại Sản phẩm";
            dgvHang.Columns[2].HeaderText = "Đơn Giá";
            dgvHang.Columns[4].HeaderText = "Ảnh";
            dgvHang.Columns[5].HeaderText = "Đơn vị tính";
            dgvHang.Columns[0].Width = 80;
            dgvHang.Columns[1].Width = 140;
            dgvHang.Columns[2].Width = 80;
            dgvHang.Columns[3].Width = 80;
            dgvHang.Columns[4].Width = 100;
            dgvHang.Columns[5].Width = 100;
            dgvHang.AllowUserToAddRows = false;
            dgvHang.EditMode = DataGridViewEditMode.EditProgrammatically;
        }
        private void frmDanhMucSanPham_Load(object sender, EventArgs e)
        {
            txtMaSP.Enabled = false;
            btnLuu.Enabled = false;
            btnHuy.Enabled = false;
            LoadDataGridView();
            cboMaLoai.DataSource = SanPham.getSanPham();
            cboMaLoai.DisplayMember = SanPham.getSanPham().Columns[1].ToString();
            cboMaLoai.ValueMember = SanPham.getSanPham().Columns[0].ToString();
            cboMaLoai.SelectedIndex = -1;
            ResetValues();
        }

        private void dgvHang_Click(object sender, EventArgs e)
        {
            if (btnThem.Enabled == false)
            {
                MessageBox.Show("Đang ở chế độ thêm mới!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtMaSP.Focus();
                return;
            }
            if (DMSanPham.getDMSanPham().Rows.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            txtMaSP.Text = dgvHang.CurrentRow.Cells[0].Value.ToString();
            txtTenSP.Text = dgvHang.CurrentRow.Cells[1].Value.ToString();
            cboMaLoai.Text = dgvHang.CurrentRow.Cells[3].Value.ToString();
            txtDonGia.Text = dgvHang.CurrentRow.Cells[2].Value.ToString();
            txtAnh.Text = dgvHang.CurrentRow.Cells[4].Value.ToString(); 
            txtDonViTinh.Text= dgvHang.CurrentRow.Cells[5].Value.ToString(); 
            //picAnh.Image = Image.FromFile(txtAnh.Text);
            btnSua.Enabled = true;
            btnXoa.Enabled = true;
            btnHuy.Enabled = true;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            btnSua.Enabled = false;
            btnXoa.Enabled = false;
            btnHuy.Enabled = true;
            btnLuu.Enabled = true;
            btnThem.Enabled = false;
            ResetValues();
            txtMaSP.Enabled = true;
            txtMaSP.Focus();
            txtDonGia.Enabled = true;
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            if (txtMaSP.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập mã hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtMaSP.Focus();
                return;
            }
            if (txtTenSP.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập tên hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtTenSP.Focus();
                return;
            }
            if (cboMaLoai.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập chất liệu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cboMaLoai.Focus();
                return;
            }
            if (txtAnh.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải chọn ảnh minh hoạ cho hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                btnOpen.Focus();
                return;
            }
            if (DMSanPham.KiemTraTonTai(txtMaSP.Text).Rows.Count>0)
            {
                MessageBox.Show("Mã hàng này đã tồn tại, bạn phải chọn mã hàng khác", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtMaSP.Focus();
                return;
            }
            DTO_DMSanPham tv = new DTO_DMSanPham(txtMaSP.Text,txtTenSP.Text,Convert.ToInt32(txtDonGia.Text),cboMaLoai.Text,txtAnh.Text,txtDonViTinh.Text);
            DMSanPham.themDMSanPham(tv);
            LoadDataGridView();
            ResetValues();
            btnXoa.Enabled = true;
            btnThem.Enabled = true;
            btnSua.Enabled = true;
            btnHuy.Enabled = false;
            btnLuu.Enabled = false;
            txtMaSP.Enabled = false;
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (DMSanPham.getDMSanPham().Rows.Count == 0)
            {
                MessageBox.Show("Không còn dữ liệu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (txtMaSP.Text == "")
            {
                MessageBox.Show("Bạn chưa chọn bản ghi nào", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtMaSP.Focus();
                return;
            }
            if (txtTenSP.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập tên hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtTenSP.Focus();
                return;
            }
            if (cboMaLoai.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập chất liệu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cboMaLoai.Focus();
                return;
            }
            if (txtAnh.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải ảnh minh hoạ cho hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtAnh.Focus();
                return;
            }
            DTO_DMSanPham tv = new DTO_DMSanPham(txtMaSP.Text,txtTenSP.Text,Convert.ToInt32(txtDonGia.Text),cboMaLoai.Text,txtAnh.Text,txtDonViTinh.Text);
            DMSanPham.suaDMSanPham(tv);
            LoadDataGridView();
            ResetValues();
            btnHuy.Enabled = false;
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (DMSanPham.getDMSanPham().Rows.Count == 0)
            {
                MessageBox.Show("Không còn dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (txtMaSP.Text == "")
            {
                MessageBox.Show("Bạn chưa chọn bản ghi nào", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (MessageBox.Show("Bạn có muốn xoá bản ghi này không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                DMSanPham.xoaDMSanPham(txtMaSP.Text);
                LoadDataGridView();
                ResetValues();
            }
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            ResetValues();
            btnXoa.Enabled = true;
            btnSua.Enabled = true;
            btnThem.Enabled = true;
            btnHuy.Enabled = false;
            btnLuu.Enabled = false;
            txtMaSP.Enabled = false;
        }
    }
}
