﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO_QuanLyBanHang;
using DAO_QuanLyBanHang;
using System.Data;

namespace BUS_QuanLyBanHang
{
    public class BUS_DMSanPham
    {
        DAO_DMSanPham DMSanPham = new DAO_DMSanPham();
        public DataTable getDMSanPham()
        {
            return DMSanPham.getDMSanPham();
        }
        public bool themDMSanPham(DTO_DMSanPham tv)
        {
            return DMSanPham.themDMSanPham(tv);
        }
        public bool suaDMSanPham(DTO_DMSanPham tv)
        {
            return DMSanPham.suaDMSanPham(tv);
        }
        public bool xoaDMSanPham(string tv)
        {
            return DMSanPham.xoaDMSanPham(tv);
        }
        public DataTable KiemTraTonTai(string MaKH)
        {
            return DMSanPham.KiemTraTonTai(MaKH);
        }
    }
}
