﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO_QuanLyBanHang;
using DAO_QuanLyBanHang;
using System.Data;

namespace BUS_QuanLyBanHang
{
    public class BUS_KhachHang
    {
        DAO_KhachHang KhachHang = new DAO_KhachHang();
        public DataTable getKhachHang()
        {
            return KhachHang.getKhachHang();
        }
        public bool themKhachHang(DTO_KhachHang tv)
        {
            return KhachHang.themKhachHang(tv);
        }
        public bool suaKhachHang(DTO_KhachHang tv)
        {
            return KhachHang.suaKhachHang(tv);
        }
        public bool xoaKhachHang(string tv)
        {
            return KhachHang.xoaKhachHang(tv);
        }
        public DataTable KiemTraTonTai(string MaKH)
        {
            return KhachHang.KiemTraTonTai(MaKH);
        }
    }
}
