﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO_QuanLyBanHang;
using DAO_QuanLyBanHang;
using System.Data;


namespace BUS_QuanLyBanHang
{
    public class BUS_SanPham
    {
        DAO_SanPham SanPham = new DAO_SanPham();
        public DataTable getSanPham()
        {
            return SanPham.getSanPham();
        }
        public bool themSanPham(DTO_SanPham tv)
        {
            return SanPham.themSanPham(tv);
        }
        public bool suaSanPham(DTO_SanPham tv)
        {
            return SanPham.suaSanPham(tv);
        }
        public bool xoaSanPham(string tv)
        {
            return SanPham.xoaSanPham(tv);
        }
        public DataTable KiemTraTonTai(string MaKH)
        {
            return SanPham.KiemTraTonTai(MaKH);
        }
    }
}
