﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO_QuanLyBanHang;
using DAO_QuanLyBanHang;
using System.Data;

namespace BUS_QuanLyBanHang
{
    public class BUS_NhanVien
    {
        DAO_NhanVien NhanVien = new DAO_NhanVien();
        public DataTable getNhanVien()
        {
            return NhanVien.getNhanVien();
        }
        public bool themNhanVien(DTO_NhanVien tv)
        {
            return NhanVien.themNhanVien(tv);
        }
        public bool suaNhanVien(DTO_NhanVien tv)
        {
            return NhanVien.suaNhanVien(tv);
        }
        public bool xoaNhanVien(string tv)
        {
            return NhanVien.xoaNhanVien(tv);
        }
        public DataTable KiemTraTonTai(string MaKH)
        {
            return NhanVien.KiemTraTonTai(MaKH);
        }
    }
}
