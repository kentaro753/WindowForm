﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO_QuanLyBanHang;
using DAO_QuanLyBanHang;
using System.Data;

namespace BUS_QuanLyBanHang
{
    public class BUS_HoaDon
    {
        BUS_HoaDon HoaDon = new BUS_HoaDon();
        public DataTable getHoaDon()
        {
            return HoaDon.getHoaDon();
        }
        public bool themHoaDon(DTO_HoaDon tv)
        {
            return HoaDon.themHoaDon(tv);
        }
        public bool xoaHoaDon(string tv)
        {
            return HoaDon.xoaHoaDon(tv);
        }
        public DataTable KiemTraTonTai(string MaKH)
        {
            return HoaDon.KiemTraTonTai(MaKH);
        }
    }
}
